

import UIKit
import Vision
import VisionKit

class ViewController: UIViewController {
    
    //Variable to store the processed image
    var image: UIImage?
    //Outlet of text view that will show result of processed image
    @IBOutlet private weak var textView: UITextView!
    //Outlet of activity indicator shown while the image processes
    @IBOutlet private weak var activityIndicator: UIActivityIndicatorView!
    
    // Vision requests to be performed on each image processed.
    private var requests = [VNRequest]()
    
    // Dispatch queue to perform Vision requests.
    private let textRecognitionWorkQueue = DispatchQueue(label: "TextRecognitionQueue",
                                                         qos: .userInitiated, attributes: [], autoreleaseFrequency: .workItem)
    //Variable to store the text of the processed image
    private var resultingText = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateProcessedText()
    }
    
    /*
     Method name: updateProcessedText
     Description: this method recognises the text and updates the observation result
     */
    private func updateProcessedText() {
        let textRecognitionRequest = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                print("The observations are of an unexpected type.")
                return
            }
            // Concatenate the recognised text from all the observations.
            let maximumCandidates = 1
            for observation in observations {
                guard let candidate = observation.topCandidates(maximumCandidates).first else { continue }
                do {
                  let detector = try NSDataDetector(types: NSTextCheckingAllTypes)
                  let range = NSRange(candidate.string.startIndex..<candidate.string.endIndex, in: candidate.string)
                  detector.enumerateMatches(in: candidate.string,
                                            options: [],
                                            range: range) { (match, flags, _) in
                      guard let match = match else {
                          return
                      }

                      switch match.resultType {
                      case .date:
                          self.resultingText += "Bill Date: \(candidate.string)" + "\n"
                      case .phoneNumber:
                          self.resultingText += "Phone Number: \(candidate.string)" + "\n"
                      case .address:
                        self.resultingText += "Address: \(candidate.string)" + "\n"
                      default:
                          return
                      }
                  }
                } catch {
                   print("handle error")
                }
            }
        }
        // specify the recognition level
        textRecognitionRequest.recognitionLevel = .accurate
        self.requests = [textRecognitionRequest]
    }
    
    /*
     Method name: choosePhotoAction
     Description: This action is calle don  the click of the choose photo button. Allows user to choose photo from the photo library
     */
    @IBAction func choosePhotoAction(_ sender: Any) {
        presentPhotoPicker(type: .photoLibrary)
    }
    
    /*
     Method name: presentPhotoPicker
     Description: This method presents the photo library
     */
    fileprivate func presentPhotoPicker(type: UIImagePickerController.SourceType) {
        let controller = UIImagePickerController()
        controller.sourceType = type
        controller.delegate = self
        present(controller, animated: true, completion: nil)
    }
    
    /*
     Method name: processImage
     Description: This method handles the image request sent
     */
    func processImage() {
        
        //Clears all present text
        resultingText = ""
        var xyz = ""
        guard let image = image else { return }
        
        textRecognitionWorkQueue.async {
            if let cgImage = image.cgImage {
                let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try requestHandler.perform(self.requests)
                } catch {
                    print(error)
                }
            }
            self.resultingText += "\n\n"
            
//            let detectorType: NSTextCheckingResult.CheckingType = [.allCustomTypes]
//            do {
//                let detector = try NSDataDetector(types: detectorType.rawValue)
//                let results = detector.matches(in: self.resultingText, options: [], range: NSRange(location: 0, length:
//                    self.resultingText.utf16.count))
//
//                for result in results {
//                    if let range = Range(result.range, in: self.resultingText) {
//                        let matchResult = self.resultingText[range]
//                        xyz += "\(self.resultingText[range])\n"
//                        print("result: \(matchResult), range: \(result.range)")
//                    }
//                }
//
//            } catch {
//                print("handle error")
//            }
            
//            let tagger = NSLinguisticTagger(tagSchemes: [.nameType], options: 0)
//            tagger.string = self.resultingText
//            let range = NSRange(location: 0, length: self.resultingText.utf16.count)
//            let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
//            let tags: [NSLinguisticTag] = [.personalName //, .placeName, .organizationName
//            ]
//
//            tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
//                if let tag = tag, tags.contains(tag) {
//                    if let range = Range(tokenRange, in: self.resultingText) {
//                        let name = self.resultingText[range]
//                        print("\(name): \(tag)")
//                    }
//                }
//            }
            
            DispatchQueue.main.async(execute: {
                self.textView.text = self.resultingText
                self.activityIndicator.isHidden = true
            })
        }
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        dismiss(animated: true, completion: nil)
        image = info[.originalImage] as? UIImage
        processImage()
    }
}


